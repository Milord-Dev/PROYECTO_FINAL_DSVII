<footer>
    <div class="container footer">
        <div class="footer-text">
            <h3>Soma</h3>
            <p>Conoce más de 30 destinos diferentes junto a Soma, tu agencia de confianza.</p>
        </div>
        <div class="footer-links">
            <div>
            <h4>Support</h4>
            <ul>
                <li><a href="formulario.php">Contact us</a></li>
            </ul>
            </div>
        </div>
    </div>
    <p>&copy; 2024 Soma. Todos los derechos reservados.</p>
</footer>
</body>
</html>